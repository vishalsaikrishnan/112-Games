Readme

Candy Crush

This is a game that involves a board of candies, and the user has to switch cerdtain candies to make 3, 4, or 5 in a row of one candy. Once this happens, the candies “break”, new candies appear, and the player gets points. A lollipop candy will break its row and column. A bomb candy will remove any candy from the board. Additionally, every 8 moves, the user will receive a cupcake, which can remove any candy from the board. If the user can’t find a move in over 5 seconds, a hint feature that will be called to find the best possible next move for the player. This game also features a custom board option, where the player can create a board of their choice.


How to run

Load up the game, and the main menu will direct the user from there. Press s to start. Press L for leaderboard. Press C for custom board option, and Press I to see instructions. In instructions, the user can press A to see a demo of the game, which the AI will show.


Libraries used

import math, copy, random, decimal
from cmu_112_graphics import *
from PIL import Image
from os import path


No shortcuts

Youtube link: https://www.youtube.com/watch?v=cLd4T8iwKdg

