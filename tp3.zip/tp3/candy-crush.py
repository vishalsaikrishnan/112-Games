import math, copy, random, decimal
from cmu_112_graphics import *
from PIL import Image
from os import path


# 1 - green candy  https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.cgtrader.com%2F3d-models%2Ffood%2Fmiscellaneous%2Fcandy-green-3d-model&psig=AOvVaw0o85AOJn-TrCKYAEaNjfje&ust=1619991387012000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJDguLC4qfACFQAAAAAdAAAAABAD
# 2 - purple candy https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.ebay.com%2Fp%2F8007546358&psig=AOvVaw1JDpDjyhfNyhxR55adrE8D&ust=1619991411166000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCKC2v7u4qfACFQAAAAAdAAAAABAD
# 3 - red candy  https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.buzzfeed.com%2Florynbrantz%2Fwhat-does-your-favorite-candy-crush-candy-say-a&psig=AOvVaw3MLyQ06OssxJnnRpPt8lIk&ust=1619991484528000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPCY69u4qfACFQAAAAAdAAAAABAD
# 4 - yellow candy https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pinterest.com%2Fpin%2F17240411060175646%2F&psig=AOvVaw0FAfjyp9rGv2_mM9g_s2gc&ust=1619991502669000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMCb-Oa4qfACFQAAAAAdAAAAABAD
# 5 - blue candy  https://www.google.com/url?sa=i&url=https%3A%2F%2Fgiphy.com%2Fgifs%2Fcandycrush-candy-crush-nutcracker-friends-loEFFOBq7clSKLL8qC&psig=AOvVaw3ZY_4hsBD4-vGLrVKpTVBG&ust=1619729893934000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCLDB9ZrqofACFQAAAAAdAAAAABAI
# 6 - orange candy https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.renderhub.com%2Fdcbittorf%2Forange-hard-candy&psig=AOvVaw23B9u4dv3BbH0HP8qDioXv&ust=1619991465297000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPiu6NC4qfACFQAAAAAdAAAAABAD

# 7 - lollipop https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.com%2Ffancy-dress-warehouse-GJ375-Lollipop%2Fdp%2FB000T5EEW6&psig=AOvVaw31-WVjKyRHoq8prbpSS-qC&ust=1619991529574000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMC80u-4qfACFQAAAAAdAAAAABAD
# 8 - bomb https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.prischew.com%2Ftechgames%2Fbeat-exploding-cake-bomb-candy-crush%2F&psig=AOvVaw27W1edX52N7yX7JU7sXhLE&ust=1619991543250000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJimrfa4qfACFQAAAAAdAAAAABAD
# 9 - cupcake https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.cleanpng.com%2Fpng-sweet-candies-2-cookie-crush-candy-match-3-candy-c-3895437%2F&psig=AOvVaw3vMRqV43FpSzLWHu4GSIKt&ust=1619991618848000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCLicopq5qfACFQAAAAAdAAAAABAD



def appStarted(app):
    app.rows = app.cols = 10
    logistics(app)
    app.board = createBoard(app, app.rows, app.cols)
    app.screen = 'beg'
    app.darkMode = False
    app.shape = 'square'
    app.moves = 0
    app.score = 0
    app.highScore = False
    app.delicious = False
    app.mintAnimation = [False, -1, -1]
    
    app.hasUserClicked = False
    app.highlightHint = False
    app.hint = set()
    app.custom = set()
    app.customBoard = []
    app.clickNew = False
    app.volcanoBoard = [[0,4],[0,5],
                    [1,4], [1,5],
                    [2,4], [2,5],
                    [3,4], [3,5],
                [4,3],[4,4],[4,5],[4,6],
            [5,2],[5,3],[5,4],[5,5],[5,6],[5,7],
        [6,1],[6,2],[6,3],[6,4],[6,5],[6,6],[6,7],[6,8],
        [7,0],[7,1],[7,2],[7,3],[7,4],[7,5],[7,6],[7,7],[7,8],[7,9]]
    app.notInBoard = False
    app.special = -1

    app.mint = False
    app.bomb = False
    app.cupcakes = 0
    app.cupcakeClick = False
    app.bombCoord = -1
    app.lightning = []
    app.clicked = -1
    app.selection = -1
    app.moveIt = False
    app.remove = []
    app.removeWay = ''

    app.counterAI = 0
    app.elapsedTime = 0
    app.timerDelay = 500
    app.gameOver = False


def logistics(app):
    app.marginRight = app.width*0.15
    app.marginLeft = app.width*0.02
    app.marginElse = app.height*0.05
    app.cellWidth = (app.width*0.75)/app.cols
    app.cellHeight = (app.height*0.9)/app.rows


def createBoard(app, rows, cols): ## Make randomized board with NO matches to start
    result = []
    for row in range(rows):
        temp = []
        for col in range(cols):
            if col != 0:
                prevCol = temp[col-1]
            else: prevCol = 1
            if row != 0:
                prevRow = result[row-1][col]
            else: prevRow = 1
            num = random.randint(1,6)
            while num == prevRow or num == prevCol:
                num = random.randint(1,6)
            temp += [num]
        result.append(temp)
    return result


def getCellXY(app, row, col):
    x0 = app.marginLeft + col*app.cellWidth
    x1 = x0 + app.cellWidth
    y0 = app.marginElse + row*app.cellHeight
    y1 = y0 + app.cellHeight
    return (x0,y0,x1,y1)


def getCandyPosition(app, x, y):
    (x0,y0,use,less) = getCellXY(app, 0, 0)
    candyCol = int((x-x0)/(app.cellWidth))
    candyRow = int((y-y0)/(app.cellHeight))
    return candyRow, candyCol

## Taken from 112 website 'Strings' 'Basic File IO'
def readFile(path):
    with open(path, "rt") as f:
        return f.read()

## Taken from 112 website 'Strings' 'Basic File IO'
def writeFile(path, contents):
    with open(path, "wt") as f:
        f.write(contents)

def checkLeaderboard(app):
    leadersRead = readFile("leaderboard.txt")
    leaderList = leadersRead.split('\n')
    if leaderList == ['']:
        initialScores = '0' + '\n' + '0' + '\n' + '0'
        writeFile('leaderboard.txt', initialScores)
    else:
        number1 = leaderList[0]
        number2 = leaderList[1]
        number3 = leaderList[2]
        if app.score > int(number1):
            leaderList[0], leaderList[1], leaderList[2] = app.score, number1, number2
            app.highScore = True
        elif app.score > int(number2):
            leaderList[1], leaderList[2] = app.score, number2
        elif app.score > int(number3):
            leaderList[2] = app.score
        scores = f'{leaderList[0]}'+'\n'+f'{leaderList[1]}'+'\n'+f'{leaderList[2]}'
        writeFile('leaderboard.txt', scores)



def whichCandy(app, candyNum):
    if candyNum == 1:
        return 'green-candy'
    elif candyNum == 2:
        return 'purple-candy'
    elif candyNum == 3:
        return 'red-candy'
    elif candyNum == 4:
        return 'yellow-candy'
    elif candyNum == 5:
        return 'blue-candy'
    elif candyNum == 6:
        return 'orange-candy'
    elif candyNum == 7:
        return 'lollipop'
    elif candyNum == 8:
        return 'bomb'


def isSelectionLegal(app): ## Check if the click is one box away from previous selection
    if (((app.selection[0] == app.clicked[0]) and 
        ((app.selection[1] == app.clicked[1]+1) or 
        (app.selection[1] == app.clicked[1]-1)))
        or 
        ((app.selection[1] == app.clicked[1]) and 
        ((app.selection[0] == app.clicked[0]+1) or 
        (app.selection[0] == app.clicked[0]-1)))):
        return True
    else: return False


def chooseCustomBoard(app, event):
    app.score = app.moves = 0
    if (app.marginLeft <= event.x <= (app.width*0.75) and 
        app.marginElse <= event.y <= app.height-app.marginElse):
        app.clicked = getCandyPosition(app,event.x,event.y)
        if app.clicked in app.custom:
            app.custom.remove(app.clicked)
        else: app.custom.add((getCandyPosition(app, event.x, event.y)))


def checkCustomBoardLegal(app):
    count = 0
    possible = [(1,0),(-1,0),(0,1),(0,-1)]
    if len(app.custom) < 25:
        return False
    for (row,col) in app.custom:
        count = 0
        for nextRow, nextCol in possible:
            if (row+nextRow, col+nextCol) in app.custom:
                count += 1
        if count >= 2:
            continue
        else: return False   
    smallestRow = smallestCol = 9
    largestRow = largestCol = 0    
    for (row,col) in app.custom:
        if row < smallestRow:
            smallestRow = row
        elif row > largestRow:
            largestRow = row
        if col < smallestCol:
            smallestCol = col
        elif col > largestCol:
            largestCol = col
    rowRanges = dict()
    colRanges = dict()
    for row in range(smallestRow, largestRow+1):
        rowRanges[row] = 0
    for col in range(smallestCol, largestCol+1):
        colRanges[col] = 0
    for (row,col) in app.custom:
        rowRanges[row] = 1
        colRanges[col] = 1
    for row in rowRanges:
        if rowRanges[row] == 0:
            return False
    for col in colRanges:
        if colRanges[col] == 0:
            return False
    return True


def mousePressed(app, event):
    if app.gameOver: return
    app.hasUserClicked = True
    app.highlightHint = False
    app.hint = set()
    if app.screen == 'custom':
        chooseCustomBoard(app, event)
        return
    if ((app.cupcakes > 0) and 
    (app.width*0.85 <= event.x <= app.width*0.95 and app.height*0.7<=event.y<=app.height*0.9)):
        app.cupcakeClick = True
    elif (app.marginLeft <= event.x <= (app.width*0.75) and 
        app.marginElse <= event.y <= app.height-app.marginElse):
        app.clicked = list(getCandyPosition(app, event.x, event.y))
        if app.cupcakeClick:
            app.special = app.clicked
            removeMintOrBomb(app, event, 0)
            app.cupcakeClick = False
            app.cupcakes -= 1
            return
        if app.shape == 'custom':
            if tuple(app.clicked) not in app.custom:
                app.notInBoard = True
                return
            else: app.notInBoard = False
        elif app.shape == 'volcano':
            if app.clicked not in app.volcanoBoard:
                app.notInBoard = True
                return
            else: app.notInBoard = False
        if app.moveIt==False:
            app.selection = app.clicked
            if app.board[app.clicked[0]][app.clicked[1]] == 7:
                app.mint = True
            if app.board[app.clicked[0]][app.clicked[1]] == 8:
                app.bomb = True
            app.moveIt = True
        else: 
            if isSelectionLegal(app) == False:
                app.selection = app.clicked
                if app.board[app.clicked[0]][app.clicked[1]] == 7:
                    app.mint = True
                if app.board[app.clicked[0]][app.clicked[1]] == 8:
                    app.bomb = True
                app.moveIt = True
            else:
                app.moves += 1
                temp = app.board[app.selection[0]][app.selection[1]]
                temp2 = app.board[app.clicked[0]][app.clicked[1]]
                app.board[app.selection[0]][app.selection[1]] = temp2
                app.board[app.clicked[0]][app.clicked[1]] = temp
                if app.bomb or app.mint:
                    app.special = app.clicked
                    other = app.selection
                    removeMintOrBomb(app, event, other)
                app.mint = app.bomb = app.moveIt = False 
            if app.moves%8==0 and app.moves>0:
                app.cupcakes += 1


def regularCheck(app, row, col): ## Check if theres a 3 in a row anywhere on board
    if col < app.cols-2:
        if (app.board[row][col] == app.board[row][col+1] and 
                    app.board[row][col] == app.board[row][col+2]):
            if mintCreate(app, row, col, 'row'):
                return True
            app.remove = [(row, col),(row, col+1), (row, col+2)]
            app.removeWay = 'row'
            app.score += 50
            return True
    if row < app.rows-2:
        if (app.board[row][col] == app.board[row+1][col] and 
                app.board[row][col] == app.board[row+2][col]):
            if mintCreate(app, row, col, 'col'):
                return True
            app.remove = [(row, col),(row+1, col),(row+2, col)]
            app.removeWay = 'col'
            app.score += 50
            return True 
    return False
    


def mintCreate(app, row, col, which): ## Checks if there is a 4 in a row on the board
    if which == 'row': 
        if col < app.cols-3:
            if (app.board[row][col] == app.board[row][col+3]):
                if bombCreate(app, row, col,'row'):
                    return True
                app.remove = [(row,col),(row,col+1),(row,col+2),(row,col+3)]
                app.removeWay = 'row4'
                app.score += 50
                return True
    elif which == 'col':
        if row < app.rows-3:
            if (app.board[row][col] == app.board[row+3][col]):
                if bombCreate(app, row, col,'col'):
                    return True
                app.remove = [(row,col),(row+1,col),(row+2,col),(row+3,col)]
                app.removeWay = 'col4'
                app.score += 50
                return True 
    return False


def bombCreate(app, row, col, which):  ## Checks if there is a 5 in a row on the board
    if which == 'row':
        if col < app.cols-4:
            if app.board[row][col] == app.board[row][col+4]:
                app.remove = [(row,col),(row,col+1),(row,col+2),(row,col+3),(row,col+4)]
                app.removeWay = 'row5'
                app.score += 50
                return True
    elif which == 'col':
        if row < app.rows-4:
            if app.board[row][col] == app.board[row+4][col]:
                app.remove = [(row,col),(row+1,col),(row+2,col),(row+3,col),(row+4,col)]
                app.removeWay = 'col5'
                app.score += 50
                return True
    return False


def checkCandyPop(app,fRow,sRow,fCol,sCol):  ## Calls the helper functions to see if there are candy matches
    for row in range(fRow, sRow):
        for col in range(fCol, sCol):
            if regularCheck(app, row, col):
                return True
    return False


def removeMintOrBomb(app, event, other): ## If there is a mint/bomb, special cases where you remove more than 5 candies
    if app.mint:
        rowRemove = app.special[0]
        colRemove = app.special[1]
        app.score += 100
        for r in range(app.rows):
            app.board[r][colRemove] = random.randint(1,6)
        for c in range(app.cols):
            for r in range(rowRemove, 0, -1):
                app.board[r][c] = app.board[r-1][c]
                app.board[0][c] = random.randint(1,6)
        app.mintAnimation = [True, rowRemove, colRemove]
    elif app.bomb:
        x0,y0,x1,y1 = getCellXY(app, app.special[0], app.special[1])
        app.bombCoord = [(x0+x1)/2, (y0+y1)/2]
        whichCandy = app.board[other[0]][other[1]]
        for r in range(app.rows):
            for c in range(app.cols):
                if app.board[r][c] == whichCandy:
                    while app.board[r][c] == whichCandy:
                        app.board[r][c] = random.randint(1,6)
                    x0,y0,x1,y1 = getCellXY(app, r, c)
                    coordinates = ((x0+x1)/2 , (y0+y1)/2)
                    app.lightning.append(coordinates)
        app.board[app.special[0]][app.special[1]] = random.randint(1,6)
        app.score += 200
    elif app.cupcakeClick:
        app.bombCoord = [app.width*0.9, app.height*0.75]
        whichCandy = app.board[app.special[0]][app.special[1]]
        for r in range(app.rows):
            for c in range(app.cols):
                if app.board[r][c] == whichCandy:
                    while app.board[r][c] == whichCandy:
                        app.board[r][c] = random.randint(1,6)
                    x0,y0,x1,y1 = getCellXY(app, r, c)
                    coordinates = ((x0+x1)/2 , (y0+y1)/2)
                    app.lightning.append(coordinates)
        app.score += 100


    
def replaceCandies(app): ## Replaces the matched candies with new random ones or bomb/mint in special cases
    if app.removeWay == 'row' or app.removeWay == 'row4' or app.removeWay == 'row5':
        for (row, col) in app.remove:
            if row == 0:
                app.board[row][col] = random.randint(1,6)
            else:
                for r in range(row, 0, -1):
                    app.board[r][col] = app.board[r-1][col]
                app.board[0][col] = random.randint(1,6)
        if app.removeWay == 'row4':
            (mintRow, mintCol) = app.remove[random.randint(1,2)]
            app.board[mintRow][mintCol] = 7
        if app.removeWay == 'row5':
            bombRow, bombCol = app.remove[2]
            app.board[bombRow][bombCol] = 8
    elif app.removeWay == 'col' or app.removeWay == 'col4' or app.removeWay == 'col5':
        first = list(app.remove[0])
        last = list(app.remove[-1])
        if first[0] == 0:
            for i in range(last[0]+1):
                app.board[i][first[1]] = random.randint(1,6)
        else:
            for i in range(last[0],-1,-1):
                if i - len(app.remove)>=0:
                    app.board[i][first[1]] = app.board[i-len(app.remove)][first[1]]
                else:
                    app.board[i][first[1]] = random.randint(1,6)
        if app.removeWay == 'col4':
            (mintRow, mintCol) = app.remove[3]
            app.board[mintRow][mintCol] = 7
        if app.removeWay == 'col5':
            bombRow, bombCol = app.remove[2]
            app.board[bombRow][bombCol] = 8
    app.delicious = True
    


## Inspiration and [for loop/return None] backbone from WordSearch on 112 website
def findHint(app):
    tempThree = tempFour = None
    for row in range(app.rows):
        for col in range(app.cols):
            result = doMoveForHint(app, row, col)
            if result != None:
                if len(app.hint) == 4:
                    tempThree = app.hint
                    continue
                elif len(app.hint) == 5:
                    tempFour = app.hint
                    continue
                elif len(app.hint) == 6:
                    app.highlightHint = True
                    return
    if tempFour != None:
        app.hint = tempFour
        app.highlightHint = True
        return
    elif tempThree != None:
        app.hint = tempThree
        app.highlightHint = True
        return    
    app.clickNew = True
    app.hint = set()
    return None


def doMoveForHint(app, row, col):
    tempThree = tempFour = None
    possibleMoves = [(0,1),(0,-1),(1,0),(-1,0)]
    for (drow ,dcol) in possibleMoves:
        if (0 <= drow + row < app.rows) and (0 <= dcol+col < app.cols):
            temp = app.board[row][col]
            otherTemp = app.board[drow+row][dcol+col]
            app.board[drow+row][dcol+col] = temp
            app.board[row][col] = otherTemp
            if checkCandyPop(app,max(0,drow+row-5),min(drow+row+5,app.rows),max(0,dcol+col-5), min(app.cols,dcol+col+5)):
                app.hint = set(app.remove)
                if (row,col) in app.hint:
                    app.hint.add((row+drow,col+dcol))
                else: app.hint.add((row,col))
                app.remove = []
            app.board[row][col] = temp
            app.board[drow+row][dcol+col] = otherTemp
            if app.shape == 'custom' or app.shape == 'volcano':
                if checkIfHintNotInBoard(app):
                    continue
            if len(app.hint) == 6:
                return True
            if len(app.hint) == 5:
                tempFour = app.hint
                continue
            elif len(app.hint) == 4:
                tempThree = app.hint
                continue
    if tempFour != None:
        app.hint = tempFour
        return True
    elif tempThree != None:
        app.hint = tempThree
        return True
    return None


def checkIfHintNotInBoard(app):
    if app.shape == 'volcano':
        for (row,col) in list(app.hint):
            if [row,col] not in app.volcanoBoard:
                return True
    elif app.shape == 'custom':
        for (row,col) in list(app.hint):
            if (row,col) not in app.custom:
                return True
    return False



##################################
######### AI FUNCTIONS ###########
##################################

def doMoveAI(app):
    delay = 0
    whatRows = set()
    whatCols = set()
    rowMove = dict()
    colMove = dict()
    theRow = -1
    theCol = -1
    theOtherRow = -1
    theOtherCol = -1
    tempList = []
    theCandy = -1
    theOtherCandy = -1
    for (row,col) in list(app.hint):
        whatRows.add(row)
        rowMove[row] = rowMove.get(row, 0) + 1
        whatCols.add(col)
        colMove[col] = colMove.get(col, 0) + 1
    if len(whatRows) == 2:
        for rowKeys in rowMove:
            if rowMove[rowKeys] == 1:
                theRow = rowKeys
            elif rowMove[rowKeys] > 1:
                theOtherRow = rowKeys
        for colKeys in colMove:
            if colMove[colKeys] == 2:
                theCol = colKeys
        for i in range(10000):
            delay += 1
        temp = app.board[theRow][theCol]
        temp2 = app.board[theOtherRow][theCol]
        app.board[theRow][theCol] = temp2
        for i in range(10^10000):
            delay += 1
        app.board[theOtherRow][theCol] = temp
    elif len(whatRows) == 1:
        for (row,col) in list(app.hint):
            theRow = row
            tempList += [[row,col]]
        theCandy = app.board[theRow][tempList[0][1]]
        if app.board[theRow][tempList[1][1]] != theCandy:
            theOtherCandy = app.board[theRow][tempList[1][1]]
            theOtherCol = tempList[1][1]
            theCol = tempList[0][1]
        else: 
            theOtherCandy = app.board[theRow][tempList[2][1]]
            theOtherCol = tempList[2][1]
            theCol = tempList[3][1]
        temp = app.board[theRow][theCol]
        temp2 = app.board[theRow][theOtherCol]
        app.board[theRow][theCol] = temp2
        for i in range(10^10000):
            delay += 1
        app.board[theRow][theOtherCol] = temp
    elif len(whatCols) == 2:
        for colKeys in colMove:
            if colMove[colKeys] == 1:
                theCol = colKeys
            elif colMove[colKeys] > 1:
                theOtherCol = colKeys
        for rowKeys in rowMove:
            if rowMove[rowKeys] > 1:
                theRow = rowKeys
        for i in range(10000):
            delay += 1
        temp = app.board[theRow][theCol]
        temp2 = app.board[theRow][theOtherCol]
        app.board[theRow][theCol] = temp2
        for i in range(10^100000):
            delay += 1
        app.board[theRow][theOtherCol] = temp
    elif len(whatCols) == 1:
        for (row,col) in list(app.hint):
            theCol = col
            tempList += [[row,col]]
        theCandy = app.board[tempList[0][0]][theCol]
        if app.board[tempList[1][0]][theCol] != theCandy:
            theOtherCandy = app.board[tempList[1][0]][theCol]
            theOtherRow = tempList[1][0]
            theRow = tempList[0][0]
        else: 
            theOtherCandy = app.board[tempList[2][0]][theCol]
            theOtherCol = tempList[2][0]
            theCol = tempList[3][0]
        temp = app.board[theRow][theCol]
        temp2 = app.board[theOtherRow][theCol]
        app.board[theRow][theCol] = temp2
        for i in range(10^10000):
            delay += 1
        app.board[theOtherRow][theCol] = temp



def artificialGame(app):
    delay = 0
    if app.counterAI == 0:
        findHint(app)
        for (row,col) in app.hint:
            if app.board[row][col] == 7 or app.board[row][col] == 8:
                app.board[row][col] = random.randint(1,6)
                app.counterAI = 2
                app.hint = set()
                return
        app.counterAI += 1
        return
    elif app.counterAI == 1:
        doMoveAI(app)
        app.counterAI += 1
    elif app.counterAI == 2:
        for i in range(10):
            if checkCandyPop(app,0,app.rows, 0, app.cols):
                replaceCandies(app)
        app.counterAI += 1
    elif app.counterAI == 3:
        for i in range(10^20000):
            delay += 1
        app.counterAI = 0



def keyPressed(app, event):
    if event.key == 'r':
        appStarted(app)
    elif event.key == 'd' and app.screen == 'game':
        app.darkMode = not app.darkMode
    elif event.key == 'i' and app.screen == 'beg':
        app.screen = 'instructions'
    elif event.key == 's' and app.screen == 'beg':
        app.screen = 'game'
    elif event.key == 'l' and app.screen == 'beg' or app.screen == 'gameOver':
        app.screen = 'leaderboard'
    elif event.key == 'b' and app.screen == 'instructions':
        app.screen = 'beg'
    elif event.key == 'b' and app.screen == 'customFalse':
        app.screen = 'custom'
    elif event.key == 'b' and app.screen == 'custom':
        app.screen = 'beg'
    elif event.key == 'c' and app.screen != 'game':
        app.screen = 'custom'
    elif event.key == 'a' and app.screen == 'instructions':
        app.shape = 'artificial'
        app.screen = 'game'
    elif event.key == 'Enter' and app.screen == 'custom':
        temptwo = checkCustomBoardLegal(app)
        if temptwo:
            app.shape = 'custom'
            app.screen = 'game'
        else:
            app.screen = 'customFalse'
    elif event.key == 'n' and (app.shape == 'custom' or app.shape == 'volcano'):
        app.clickNew = False
        app.board = createBoard(app,app.rows,app.cols)
    elif event.key == 'v' and app.shape != 'custom':
        app.shape = 'volcano'
    

def checkGameOver(app):
    if app.moves >= 20:
        app.gameOver = True
        app.screen = 'gameOver'
        checkLeaderboard(app)


def timerFired(app):
    if app.screen != 'game' or app.gameOver:
        return
    tempScore = app.score
    if app.shape == 'artificial':
        artificialGame(app)
        app.score = app.moves = 0
        return
    if app.screen != 'artificial':
        if app.hasUserClicked:
            app.elapsedTime = 0
            app.hasUserClicked = False
        else:
            app.elapsedTime += 1/3
            if app.elapsedTime >= 6:
                findHint(app)
                app.score = tempScore
    if app.bomb or app.mint or app.clicked == -1:
        return
    if app.lightning != []:
        delay = 0
        for i in range(10000):
            delay+=1
        app.lightning = []
        app.bombCoord = -1
    if app.delicious:
        delay = 0
        for i in range(2000):
            delay+=1
        app.delicious = False
    if app.mintAnimation[0]:
        delay = 0
        for i in range(1000):
            delay+=1
        app.mintAnimation = [False,-1,-1]
    if checkCandyPop(app,0,app.rows, 0, app.cols):
        if app.shape == 'custom': 
            for (row,col) in app.remove:
                if (row,col) not in app.custom:
                    app.board[row][col] = random.randint(1,6)
                    app.score = tempScore
                    return
        elif app.shape == 'volcano':
            for (row,col) in app.remove:
                if [row,col] not in app.volcanoBoard:
                    app.board[row][col] = random.randint(1,6)
                    app.score = tempScore
                    return
        replaceCandies(app)
    checkGameOver(app)
        

    


#####################################################################
###################### DRAW FUNCTIONS ###############################
#####################################################################

def drawBlankBoard(app, canvas):
    for row in range(app.rows):
        for col in range(app.cols):
            (x0,y0,x1,y1) = getCellXY(app, row, col)
            canvas.create_rectangle(x0,y0,x1,y1, width = 2)


def drawCustomChoices(app, canvas):
    for row,col in app.custom:
        (x0,y0,x1,y1) = getCellXY(app, row, col)
        canvas.create_rectangle(x0,y0,x1,y1,
                                        width = 0, fill = 'yellow')


def drawCustomBoardIllegal(app,canvas):
    canvas.create_text(app.width/2, app.height*0.4, text = 'Custom Board Choice is Illegal',
                                font = 'Times 48 bold')
    canvas.create_text(app.width/2, app.height*0.55, text = 'Please Try Again',
                                font = 'Times 48 bold', fill = 'red')
    canvas.create_text(app.width/2, app.height*0.7, text = 'Press b to go back to Custom Board Screen',
                                font = 'Times 48 bold', fill = 'blue')



def drawBoard(app, canvas):
    for row in range(app.rows):
        for col in range(app.cols):
            (x0,y0,x1,y1) = getCellXY(app, row, col)
            canvas.create_rectangle(x0,y0,x1,y1, width = 0)
            candyImage = Image.open(f'{whichCandy(app, app.board[row][col])}' + '.png')
            canvas.create_image((x0+x1)/2, (y0+y1)/2, 
                                image = ImageTk.PhotoImage(candyImage))
            # whichCandy(app, app.board[row][col]) == 'blue-candy'
            # candyResized = candyImage.resize((int(app.cellWidth*0.9), int(app.cellHeight*0.9)))
            # canvas.create_image((x0+x1)/2, (y0+y1)/2, 
            #                         image = ImageTk.PhotoImage(candyResized))


def drawCustomBoard(app,canvas):
    for row,col in list(app.custom):
        (x0,y0,x1,y1) = getCellXY(app, row, col)
        canvas.create_rectangle(x0,y0,x1,y1, width = 0)
        candyImage = Image.open(f'{whichCandy(app, app.board[row][col])}' + '.png')
        canvas.create_image((x0+x1)/2, (y0+y1)/2, 
                                image = ImageTk.PhotoImage(candyImage))


def drawRulesForCustom(app, canvas):
    canvas.create_text(app.width*0.88, app.height*0.45, text = 'Rules',
                        font = 'Arial 24 bold')
    yIncrement = 0.04*app.height
    count = 0
    rules = ['1) Each box has to be in contact', 
                'with atleast 2 other boxes',
                '\n',
             '2) Atleast 25 boxes have',
                'to be selected',
                '\n',
             '3) There should be no breaks',
                'in the custom board']
    for line in rules:
        canvas.create_text(app.width*0.88, app.height/2 + count*yIncrement, 
                    text = f'{line}', font = 'Arial 12 bold')
        count += 1
    canvas.create_text(app.width*0.88, app.height*0.95,
                        text = 'Press b to go back to the home screen',
                        fill = 'red', font = 'Arial 12 bold')


def drawVolcanoBoard(app, canvas):
    whichCells = app.volcanoBoard
    whichRow = 0
    for row in range(8):
        for col in range(app.cols):
            if row == whichRow:
                if [row,col] in whichCells:
                    (x0,y0,x1,y1) = getCellXY(app, row, col)
                    canvas.create_rectangle(x0,y0,x1,y1,
                                        width = 0, outline = 'black')
                    
                    candyImage = Image.open(f'{whichCandy(app, app.board[row][col])}' + '.png')
                    canvas.create_image((x0+x1)/2, (y0+y1)/2, 
                                image = ImageTk.PhotoImage(candyImage))
        whichRow += 1


def drawTitle(app, canvas):
    colors = ['blue', 'red', 'purple', 'yellow', 'green', 'orange', 'navy',
            'dark green', 'indigo', 'maroon', 'aqua'] 
    title = ['Candy','Crush']
    canvas.create_oval(app.width*0.8, app.height*0.05,
                            app.width*0.995, app.height*0.25, fill = 'pink')
    for line in title:
        colorIndex1 = random.randrange(len(colors))
        colorIndex2 = random.randrange(len(colors))
        canvas.create_text(app.width*0.9, app.height*0.1, text = 'Candy',
                            font = 'Calibri 42 bold', 
                            fill = f'{colors[colorIndex1]}')
        canvas.create_text(app.width*0.9, app.height*0.18, text = 'Crush',
                            font = 'Calibri 42 bold', 
                            fill = f'{colors[colorIndex2]}')
    

def drawScoreAndMoves(app, canvas):
    canvas.create_rectangle(app.width*0.85, app.height*0.35,
                        app.width*0.95, app.height*0.45, fill = 'light blue')
    canvas.create_text(app.width*0.9, app.height*0.4, 
                    text = 'Score' + '\n' + f'    {app.score}', 
                    font = 'Times 24')
    canvas.create_rectangle(app.width*0.85, app.height*0.5,
                        app.width*0.95, app.height*0.6, fill = 'light green')
    canvas.create_text(app.width*0.9, app.height*0.55, 
                    text = 'Moves' + '\n' + f'    {app.moves}', 
                    font = 'Times 24')
    canvas.create_text(app.width*0.9, app.height*0.68,
                    text = 'Cupcakes',
                    font = 'Arial 20 bold', fill = 'magenta')


def drawCupcakes(app, canvas):
    yIncrement = 0
    temp = app.cupcakes
    for i in range(temp):
        cupcake = Image.open('cupcake.png')
        cupcakeResized = cupcake.resize((int(app.cellWidth*0.7), int(app.cellHeight*0.7)))
        canvas.create_image(app.width*0.9, app.height*0.75 + yIncrement, 
                                image = ImageTk.PhotoImage(cupcakeResized))
        yIncrement += app.height*0.05


def drawMove(app, canvas):
    if app.notInBoard and (app.shape == 'custom' or app.shape == 'volcano'):
        return
    elif app.clicked != -1 and app.moveIt == True:
        (x0,y0,x1,y1) = getCellXY(app, app.clicked[0], app.clicked[1])
        canvas.create_rectangle(x0, y0, x1, y1, outline = 'red', width = 4)


def drawHint(app, canvas):
    if app.clickNew:
        return
    for row, col in list(app.hint):
        (x0,y0,x1,y1) = getCellXY(app, row, col)
        canvas.create_rectangle(x0, y0, x1, y1, outline = 'green', width = 4)


def drawLightning(app, canvas):
    if app.lightning != []:
        for (coordX, coordY) in app.lightning:
            canvas.create_line(app.bombCoord[0],app.bombCoord[1], coordX, coordY,
                    fill = 'navy', width = 3, dash = (4,2))


def drawBegScreen(app, canvas):
    ## tie-dye screen --> https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.4imprint.com%2Fproduct%2F149238-S%2FTie-Dye-Swirl-Hoodie-Screen&psig=AOvVaw2bLXD2zKiorXL1DjyJMq0D&ust=1619994406526000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPDq88rDqfACFQAAAAAdAAAAABAE
    tiedyeImage = Image.open('ti-dye.jpeg')
    dyeResized = tiedyeImage.resize((app.width, app.height))
    canvas.create_image(app.width/2,app.height/2,
                image = ImageTk.PhotoImage(dyeResized))
    canvas.create_text(app.width/2, app.height*0.3, text = 'Candy Crush',
                font = 'Arial 92 bold')
    canvas.create_text(app.width/2, app.height*0.5, text = 'Press s to start',
                font = 'Arial 48 bold')
    canvas.create_text(app.width/2, app.height*0.6, text = 'Press i to see instructions',
                font = 'Arial 32 bold')
    canvas.create_text(app.width/2, app.height*0.7, text = 'Press c to create a custom board',
                font = 'Arial 32 bold')
    canvas.create_text(app.width/2, app.height*0.8 , text = 'Press L to see leaderboard',
                font = 'Arial 32 bold')


def drawInstructions(app, canvas):
    yIncrement = 0.03*app.height
    count = 0
    colors = ['blue', 'red', 'purple', 'green', 'orange', 'hot pink',
            'dark green', 'navy', 'indigo', 'maroon', 'teal','black'] 
    messages = [
                'The goal of this game is to clear as many rows and columns as possible.',
                'You can clear candy pieces from the board by lining up', 
                '3 or more candies in a row, which is done by swapping candy pieces.',
                'You can swap candies in any direction, and when matched,',
                'the candies will crush and shift the candies above them.',
                'The regular match is 3 candies in a row.', 
                'If you match 4 candies, a lollipop will be created, and when moved,',
                'this lollipop will burst its entire row AND column.',
                'If you match 5 candies, a bomb will be created, and when this bomb is moved,',
                'it will randomly remove any number of candies from the board, and replace it with new candies.', 
                'A lightning animation will also show up.',
                'Once you reach 8 or 16 moves, you will receive a cupcake',
                'First click on the cupcake, then click on any candy on the board',
                'to remove all of that candy from the board',
                '\n',
                'Everytime you clear candy pieces, you gain points.',
                'Here are the points breakdown:',
                '3 candies --> + 50',
                '4 candies --> + 150',
                '5 candies --> + 250',
                '\n',
                '(For a challenge, change board shape between square and volcano by pressing v)',
                'To create your own custom board, press c',
                'To see a demo, press a']
    canvas.create_text(app.width/2, app.height*0.1,
                    text = 'How to Play', font = 'Arial 80 bold', fill = 'orange')
    for line in messages: ##draws each line in the instructions
        colorIndex = count%12
        canvas.create_text(app.width/2, app.height*0.2 + count*yIncrement,
                        text = f'{line}', font = 'Arial 14 bold',
                        fill = f'{colors[colorIndex]}')
        count += 1
    canvas.create_text(app.width/2, app.height*0.95,
                        text = 'Press b to go back to the home screen',
                        fill = 'red', font = 'Arial 14 bold')


def drawHowToPlay(app, canvas):
    canvas.create_text(app.width*0.88, app.height*0.2, fill = 'maroon',
                    text = 'How To Play', font = 'Arial 32 bold')
    canvas.create_text(app.width*0.88, app.height*0.35, fill = 'black',
                    text = 'This demo will NOT show' + '\n'
                        + 'lollipops or mint bombs or'+ '\n'+'cupcakes in action',
                        font = 'Arial 16 bold')
    canvas.create_text(app.width*0.89, app.height*0.8, fill = 'red',
                    text = 'Press r to back'+'\n'+'to home screen', 
                        font = 'Arial 20 bold')


def drawAnimation(app, canvas):
    if app.mintAnimation[0]:
        (x0,y0,x1,y1) = getCellXY(app, app.mintAnimation[1], 0)
        (x2,y2,x3,y3) = getCellXY(app, app.mintAnimation[1], app.cols-1)
        (x4,y4,x5,y5) = getCellXY(app, 0, app.mintAnimation[2])
        (x6,y6,x7,y7) = getCellXY(app, app.rows-1, app.mintAnimation[2])
        canvas.create_rectangle(x0,y0,x3,y3, fill = '', outline = 'hot Pink', width = 3)
        canvas.create_rectangle(x4,y4,x7,y7, fill = '', outline = 'hot Pink', width = 3)
    elif app.delicious and app.moves%2==0 and app.elapsedTime <=0.1:
        words = ['Delicious','Superb','Awesome','YUMMY','Tasty','Scrumptious','Mouthwatering']
        (row, col) = app.remove[1]
        (x0,y0,x1,y1) = getCellXY(app, row, col)
        index = random.randint(0,6)
        canvas.create_text((x0+x1)/2,(y0+y1)/2, text = words[index], font = 'Arial 48 bold', 
                                    fill = 'aqua')


def drawLeaderboard(app, canvas):
    leaderBoard = readFile('leaderboard.txt')
    leaders = leaderBoard.split('\n')
    if leaders == ['']:
        return
    score1 = leaders[0]
    score2 = leaders[1]
    score3 = leaders[2]
    canvas.create_text(app.width/2, app.height*0.15, text = 'Candy Crush Leaderboard',
                        font = 'Times 84 bold', fill = 'purple')
    
    canvas.create_text(app.width*0.5, app.height*0.45, text = score1, font = 'Arial 54 bold')
    canvas.create_rectangle(app.width*0.35, app.height*0.5, app.width*0.65, app.height*0.8,
                            fill = 'blue')
    canvas.create_text(app.width*0.5, app.height*0.6, text = '#1', font = 'Times 48 bold',
                            fill = 'white')
    canvas.create_text(app.width/2, app.height*0.7, text = 'The Champion', font = 'Times 30 bold',
                            fill = 'yellow')

    canvas.create_text(app.width*0.25, app.height*0.55, text = score2, font = 'Arial 54 bold')
    canvas.create_rectangle(app.width*0.15, app.height*0.6, app.width*0.35, app.height*0.8,
                            fill = 'red')
    canvas.create_text(app.width*0.25, app.height*0.7, text = '#2', font = 'Times 48 bold',
                            fill = 'white')
    
    canvas.create_text(app.width*0.75, app.height*0.65, text = score3, font = 'Arial 54 bold')
    canvas.create_rectangle(app.width*0.65, app.height*0.7, app.width*0.85, app.height*0.8,
                            fill = 'orange')
    canvas.create_text(app.width*0.75, app.height*0.75, text = '#3', font = 'Times 48 bold',
                            fill = 'white')
    canvas.create_text(app.width/2, app.height*0.95,
                        text = 'Press r to go back to the home screen',
                        fill = 'black', font = 'Arial 14 bold')


def drawGameOver(app, canvas):
    canvas.create_text(app.width/2, app.height*0.3, text = 'Game Over',
                        font = 'Times 90 bold', fill = 'red')
    canvas.create_text(app.width/2, app.height*0.55,
                            text = 'Press r to restart', font = 'Times 40 bold')
    canvas.create_text(app.width/2, app.height*0.7, 
                            text = f'Your Score: {app.score}', font = 'Times 32')
    if app.highScore:
        canvas.create_text(app.width/2, app.height*0.8, text = 'NEW HIGH SCORE!!!!!',
                            fill = 'blue', font = 'Times 48')


def redrawAll(app, canvas):
    if app.screen == 'gameOver':
        drawGameOver(app,canvas)
    elif app.screen == 'beg':
        drawBegScreen(app, canvas)
    elif app.screen == 'instructions':
        drawInstructions(app, canvas)
    elif app.screen == 'leaderboard':
        drawLeaderboard(app, canvas)
    elif app.screen == 'custom':
        drawBlankBoard(app, canvas)
        drawTitle(app, canvas)
        drawRulesForCustom(app, canvas)
        drawCustomChoices(app, canvas)
    elif app.screen == 'customFalse':
        drawCustomBoardIllegal(app, canvas)
    elif app.screen == 'game':
        if app.darkMode:
            canvas.create_rectangle(0,0,app.width,app.height, fill = 'black')
        if app.shape == 'volcano':
            drawVolcanoBoard(app, canvas)
        elif app.shape == 'custom': 
            drawCustomBoard(app, canvas)
            if app.clickNew:
                canvas.create_rectangle(app.width*0.2, app.height*0.4, 
                                        app.width*0.8, app.height*0.6, fill = 'red')
                canvas.create_text(app.width/2, app.height/2, text = 'Click N to create new board',
                                    font = 'Arial 35 bold')
        elif app.shape == 'square' or app.shape == 'artificial':
            drawBoard(app, canvas)
        if app.highlightHint:
            drawHint(app, canvas)
        if app.shape == 'artificial':
            drawHowToPlay(app, canvas)
            return
        drawAnimation(app, canvas)
        drawMove(app, canvas)
        drawLightning(app, canvas)
        drawTitle(app, canvas)
        drawScoreAndMoves(app, canvas)
        drawCupcakes(app, canvas)


def main():
    runApp(width = 1000, height = 700)

if __name__ == '__main__':
    main()
